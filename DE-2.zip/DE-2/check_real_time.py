import requests
from datetime import datetime

def check_real_time(api_key):
    url = f'https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key={api_key}'
    response = requests.get(url)
    data = response.json()

    published_date = data['results']['published_date']
    current_date = datetime.today().date()

    print(f"API Published Date: {published_date}")
    print(f"Today's Date: {current_date}")

    if str(current_date) >= published_date:
        print("✅ The data is up-to-date (Real-time).")
    else:
        print("⚠️ Data might not be up-to-date.")

# Your API key
api_key = "p2Vh3eudWo2I4qyMzqcFpqgFBhfpdXPg"
check_real_time(api_key)
