import requests
import pandas as pd
from azure.storage.blob import BlobServiceClient
from io import StringIO
from datetime import datetime

# Fetch real-time data from NYT API
def fetch_nyt_latest(api_key):
    url = f'https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key={api_key}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to fetch data: {response.status_code} {response.text}")

# Convert fetched JSON to CSV format
def convert_to_csv(json_data):
    records = []
    pub_date = json_data['results']['published_date']

    for book_list in json_data['results']['lists']:
        list_name = book_list['list_name']
        for book in book_list['books']:
            records.append({
                'Published_Date': pub_date,
                'List_Name': list_name,
                'Rank': book['rank'],
                'Title': book['title'],
                'Author': book['author'],
                'Publisher': book['publisher'],
                'Weeks_On_List': book['weeks_on_list'],
                'ISBN13': book['primary_isbn13'],
                'Amazon_URL': book['amazon_product_url']
            })

    df = pd.DataFrame(records)
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    return csv_buffer.getvalue(), pub_date

# Upload CSV to Azure Data Lake Storage Gen2
def upload_csv_to_adls(storage_account_name, storage_account_key, container_name, blob_name, data):
    connection_string = (
        f"DefaultEndpointsProtocol=https;"
        f"AccountName={storage_account_name};"
        f"AccountKey={storage_account_key};"
        f"EndpointSuffix=core.windows.net"
    )

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    
    blob_client.upload_blob(data, overwrite=True)
    print(f"✅ Uploaded '{blob_name}' successfully to Azure Data Lake Storage.")

# Main function
if __name__ == "__main__":
    # User credentials and configurations
    api_key = "p2Vh3eudWo2I4qyMzqcFpqgFBhfpdXPg"
    storage_account_name = "debooks"
    storage_account_key = "6K6hOtCKgw4wGXX0xl1YRGpWt5SoSrrFWUTaM1QJVt1SlMec6au5Jr4De3gXuMwHG3Qhb2xVblGF+AStF3SyDg=="
    container_name = "rawdata"

    # Fetch data
    nyt_json = fetch_nyt_latest(api_key)

    # Convert data to CSV
    csv_data, published_date = convert_to_csv(nyt_json)
    blob_name = f"nyt_bestsellers{published_date}.csv"

    # Upload CSV to Azure
    upload_csv_to_adls(storage_account_name, storage_account_key, container_name, blob_name, csv_data)
