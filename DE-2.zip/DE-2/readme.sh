  api_key = "p2Vh3eudWo2I4qyMzqcFpqgFBhfpdXPg"
    storage_account_name = "debooks"
    storage_account_key = "6K6hOtCKgw4wGXX0xl1YRGpWt5SoSrrFWUTaM1QJVt1SlMec6au5Jr4De3gXuMwHG3Qhb2xVblGF+AStF3SyDg=="
    container_name = "rawdata"



Books API
The Books API provides information about books on The New York Times Best Sellers lists. Some lists are weekly (e.g. hardcover fiction) and some lists are monthly (e.g. audio fiction). New lists are published on the web on Wednesday around 7pm eastern time. They show up in print eleven days later in The New York Times Book Review.

The Book API provides two services:

an overview service to get all the Best Sellers lists for a given week, and
a list service to get one specific Best Sellers list for a given week or month depending on the list type.
Example Calls
https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key=yourkey
https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key=yourkey&published_date=2025-05-04
https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=yourkey
https://api.nytimes.com/svc/books/v3/lists/2025-05-04/hardcover-fiction.json?api-key=yourkey
Recent API Changes
Note: On May 15, 2025 the Books API changed.

The list and overview services return the full list of books, so pagination is no longer required.
The book reviews service was removed. Use the Article Search API instead.
The best-sellers history service was removed.
The list names service was removed.
The v2 version of the services were removed.
The services XML response format is deprecated.
If you find issues, please email code@nytimes.com.
Usage
The overview service contains all the lists and all their books for a given week. So you only need to make 1 call to get a week's worth of data and 52 calls to get a year's worth data. You can use this to populate a local database on your side. Once populated you would only need to make 1 call a week to keep it up-to-date. New lists come out at around 7pm on Wednesday eastern time.

If you call the overview endpoint with no date, it will return the current lists. In the response it has the publish date of the previous list, so you can use that to walk through all the weeks.

https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key=yourkey
https://api.nytimes.com/svc/books/v3/lists/overview.json?published_date=2025-05-18&api-key=yourkey
https://api.nytimes.com/svc/books/v3/lists/overview.json?published_date=2025-05-11&api-key=yourkey