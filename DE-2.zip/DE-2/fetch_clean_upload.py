import requests
import pandas as pd
from azure.storage.blob import BlobServiceClient
from io import StringIO
from datetime import datetime

def fetch_and_clean_nyt_data(api_key):
    url = f'https://api.nytimes.com/svc/books/v3/lists/overview.json?api-key={api_key}'
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"API request failed: {response.status_code}")

    json_data = response.json()
    pub_date = json_data['results']['published_date']

    records = []
    for book_list in json_data['results']['lists']:
        list_name = book_list['list_name']
        for book in book_list['books']:
            records.append({
                'Published_Date': pub_date,
                'List_Name': list_name,
                'Rank': book['rank'],
                'Title': book['title'].strip(),
                'Author': book['author'].strip(),
                'Publisher': book['publisher'].strip(),
                'Weeks_On_List': book['weeks_on_list'],
                'ISBN13': book['primary_isbn13'],
                'Amazon_URL': book['amazon_product_url']
            })

    df = pd.DataFrame(records)
    
    # Clean data
    df = df.dropna(subset=['Title', 'Author', 'Publisher', 'ISBN13'])
    df = df.drop_duplicates(subset=['ISBN13', 'Published_Date', 'List_Name'])

    # Convert to CSV string
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    return csv_buffer.getvalue(), pub_date

def upload_to_adls(csv_data, storage_account_name, storage_account_key, container_name, blob_name):
    connection_string = (
        f"DefaultEndpointsProtocol=https;"
        f"AccountName={storage_account_name};"
        f"AccountKey={storage_account_key};"
        f"EndpointSuffix=core.windows.net"
    )

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    
    blob_client.upload_blob(csv_data, overwrite=True)
    print(f"✅ Uploaded to Azure Data Lake as: {blob_name}")

# Main
if __name__ == "__main__":
    api_key = "p2Vh3eudWo2I4qyMzqcFpqgFBhfpdXPg"
    storage_account_name = "debooks"
    storage_account_key = "6K6hOtCKgw4wGXX0xl1YRGpWt5SoSrrFWUTaM1QJVt1SlMec6au5Jr4De3gXuMwHG3Qhb2xVblGF+AStF3SyDg=="
    container_name = "rawdata"

    csv_data, pub_date = fetch_and_clean_nyt_data(api_key)
    blob_name = f"nyt_bestsellers_cleaned_{pub_date}.csv"
    upload_to_adls(csv_data, storage_account_name, storage_account_key, container_name, blob_name)
